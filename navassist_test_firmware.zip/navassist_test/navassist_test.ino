/*
 * NavAssist — Connectivity Test Firmware
 * For bare ESP32-CAM module (no camera, no IMU, no motors needed)
 *
 * What this does:
 * - Connects to WiFi
 * - Connects to NavAssist server via WebSocket
 * - Sends heartbeats every 2 seconds
 * - Sends fake IMU readings
 * - Sends fake camera frames (no image data)
 * - Listens for haptic commands and prints them to Serial
 *
 * Required libraries (Arduino IDE Library Manager):
 *   - WebSockets by Markus Sattler
 *   - ArduinoJson by Benoit Blanchon
 */

#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>

// ============================================================
// ⚠️  EDIT THESE BEFORE FLASHING
// ============================================================
const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* SERVER_IP     = "YOUR_AWS_ELASTIC_IP";
const int   SERVER_PORT   = 3000;
// ============================================================

WebSocketsClient webSocket;
bool wsConnected = false;
int heartbeatSeq = 0;
int frameId = 0;

unsigned long lastHeartbeat = 0;
unsigned long lastImu       = 0;
unsigned long lastFrame     = 0;

void onWebSocketEvent(WStype_t type, uint8_t* payload, size_t length) {
    switch (type) {
        case WStype_CONNECTED:
            Serial.println("\n[WS] Connected to NavAssist server!");
            wsConnected = true;
            break;

        case WStype_DISCONNECTED:
            Serial.println("[WS] Disconnected. Retrying...");
            wsConnected = false;
            break;

        case WStype_TEXT: {
            StaticJsonDocument<256> doc;
            if (deserializeJson(doc, payload, length) == DeserializationError::Ok) {
                const char* topic = doc["topic"] | "";
                if (strcmp(topic, "haptic/command") == 0) {
                    const char* motor = doc["payload"]["motor"] | "none";
                    int duration      = doc["payload"]["duration_ms"] | 300;
                    Serial.printf("[Haptic] motor=%s duration=%dms\n", motor, duration);
                }
            }
            break;
        }
        default: break;
    }
}

void sendJson(const char* topic, JsonDocument& payload) {
    if (!wsConnected) return;
    StaticJsonDocument<512> envelope;
    envelope["topic"]     = topic;
    envelope["timestamp"] = millis();
    envelope["payload"]   = payload.as<JsonObject>();
    String output;
    serializeJson(envelope, output);
    webSocket.sendTXT(output);
}

void sendHeartbeat() {
    StaticJsonDocument<64> payload;
    payload["sender"]   = "esp32_test";
    payload["sequence"] = heartbeatSeq++;
    sendJson("system/heartbeat", payload);
    Serial.printf("[Heartbeat] seq=%d\n", heartbeatSeq);
}

void sendFakeImu() {
    StaticJsonDocument<128> payload;
    payload["heading_deg"] = 0;
    payload["pitch_deg"]   = 0.0;
    payload["roll_deg"]    = 0.0;
    payload["gyro_z"]      = 0.0;
    payload["calibrated"]  = true;
    sendJson("imu/orientation", payload);
}

void sendFakeFrame() {
    StaticJsonDocument<128> payload;
    payload["frame_id"]   = frameId++;
    payload["width"]      = 320;
    payload["height"]     = 240;
    payload["simulated"]  = true;
    sendJson("camera/image", payload);
    Serial.printf("[Camera] Fake frame %d sent\n", frameId);
}

void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("\n=== NavAssist Connectivity Test ===");

    Serial.printf("Connecting to %s", WIFI_SSID);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

    unsigned long start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
        delay(500);
        Serial.print(".");
    }
    Serial.println();

    if (WiFi.status() == WL_CONNECTED) {
        Serial.printf("WiFi connected! IP: %s\n", WiFi.localIP().toString().c_str());
        webSocket.begin(SERVER_IP, SERVER_PORT, "/esp32");
        webSocket.onEvent(onWebSocketEvent);
        webSocket.setReconnectInterval(3000);
        Serial.printf("Connecting to ws://%s:%d/esp32\n", SERVER_IP, SERVER_PORT);
    } else {
        Serial.printf("WiFi FAILED. Status: %d\n", WiFi.status());
    }
}

void loop() {
    webSocket.loop();
    unsigned long now = millis();

    if (now - lastHeartbeat >= 2000) {
        sendHeartbeat();
        lastHeartbeat = now;
    }
    if (now - lastImu >= 200) {
        sendFakeImu();
        lastImu = now;
    }
    if (wsConnected && now - lastFrame >= 2000) {
        sendFakeFrame();
        lastFrame = now;
    }
}
