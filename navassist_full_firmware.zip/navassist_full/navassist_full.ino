/*
 * NavAssist — Full Glasses Firmware
 * For complete ESP32-CAM + MPU-6050 + 2x Haptic Motors via ULN2003A
 *
 * Hardware confirmed:
 *   Board:    AI Thinker ESP32-CAM (OV5640 camera)
 *   IMU:      MPU-6050 (SDA=GPIO14, SCL=GPIO15)
 *   Motor 1:  ULN2003A Pin1(IN1)←GPIO12, Pin16(OUT1)→Motor1 negative
 *   Motor 2:  ULN2003A Pin2(IN2)←GPIO13, Pin15(OUT2)→Motor2 negative
 *   Power:    Both motor positives joined → 3.3V via Pin9(COM) + flip switch
 *
 * Required libraries:
 *   - WebSockets by Markus Sattler
 *   - ArduinoJson by Benoit Blanchon
 *   - MPU6050 by Electronic Cats
 */

#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <MPU6050.h>
#include "esp_camera.h"

// ============================================================
// ⚠️  EDIT THESE BEFORE FLASHING
// ============================================================
const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* SERVER_IP     = "YOUR_AWS_ELASTIC_IP";
const int   SERVER_PORT   = 3000;
// ============================================================

// Motor pins -- confirmed from circuit diagram
#define MOTOR_LEFT_PIN  12   // GPIO12 → ULN2003A Pin1 → Pin16 → Motor1
#define MOTOR_RIGHT_PIN 13   // GPIO13 → ULN2003A Pin2 → Pin15 → Motor2

// I2C pins for MPU-6050 -- confirmed from circuit diagram
#define I2C_SDA 14
#define I2C_SCL 15

// Camera pins -- AI Thinker ESP32-CAM standard
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27
#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

// ============================================================
// Globals
// ============================================================

WebSocketsClient webSocket;
MPU6050 mpu;
bool wsConnected  = false;
bool cameraReady  = false;
bool imuReady     = false;
int heartbeatSeq  = 0;
int frameId       = 0;

unsigned long lastHeartbeat = 0;
unsigned long lastImu       = 0;
unsigned long lastFrame     = 0;

// Gyroscope integration for turn detection
float cumulativeGyroZ = 0;
unsigned long lastGyroTime = 0;

// ============================================================
// WebSocket event handler
// ============================================================

void onWebSocketEvent(WStype_t type, uint8_t* payload, size_t length) {
    switch (type) {
        case WStype_CONNECTED:
            Serial.println("[WS] Connected to NavAssist server");
            wsConnected = true;
            // Startup confirmation buzz -- both motors briefly
            // so user knows glasses are connected
            fireMotor(MOTOR_LEFT_PIN, 150);
            delay(100);
            fireMotor(MOTOR_RIGHT_PIN, 150);
            break;

        case WStype_DISCONNECTED:
            Serial.println("[WS] Disconnected");
            wsConnected = false;
            break;

        case WStype_TEXT: {
            StaticJsonDocument<256> doc;
            if (deserializeJson(doc, payload, length) == DeserializationError::Ok) {
                const char* topic = doc["topic"] | "";
                if (strcmp(topic, "haptic/command") == 0) {
                    handleHapticCommand(doc["payload"].as<JsonObject>());
                }
            }
            break;
        }
        default: break;
    }
}

// ============================================================
// Haptic motor control
// ============================================================

void fireMotor(int pin, int durationMs) {
    digitalWrite(pin, HIGH);
    delay(durationMs);
    digitalWrite(pin, LOW);
}

void handleHapticCommand(JsonObject payload) {
    const char* motor = payload["motor"] | "none";
    int duration      = payload["duration_ms"] | 300;
    float intensity   = payload["intensity"] | 0.8;

    Serial.printf("[Haptic] motor=%s duration=%dms intensity=%.1f\n",
        motor, duration, intensity);

    if (strcmp(motor, "left") == 0) {
        fireMotor(MOTOR_LEFT_PIN, duration);
    }
    else if (strcmp(motor, "right") == 0) {
        fireMotor(MOTOR_RIGHT_PIN, duration);
    }
    else if (strcmp(motor, "both") == 0) {
        digitalWrite(MOTOR_LEFT_PIN,  HIGH);
        digitalWrite(MOTOR_RIGHT_PIN, HIGH);
        delay(duration);
        digitalWrite(MOTOR_LEFT_PIN,  LOW);
        digitalWrite(MOTOR_RIGHT_PIN, LOW);
    }
}

// ============================================================
// Send helper
// ============================================================

void sendJson(const char* topic, JsonDocument& payload) {
    if (!wsConnected) return;
    StaticJsonDocument<2048> envelope;
    envelope["topic"]     = topic;
    envelope["timestamp"] = millis();
    envelope["payload"]   = payload.as<JsonObject>();
    String output;
    serializeJson(envelope, output);
    webSocket.sendTXT(output);
}

// ============================================================
// Heartbeat
// ============================================================

void sendHeartbeat() {
    StaticJsonDocument<64> payload;
    payload["sender"]   = "esp32_cam";
    payload["sequence"] = heartbeatSeq++;
    sendJson("system/heartbeat", payload);
}

// ============================================================
// IMU reading -- MPU-6050
// Sends pitch, roll, gyro Z for turn detection
// No absolute heading (no magnetometer on MPU-6050)
// ============================================================

void sendImuReading() {
    int16_t ax, ay, az, gx, gy, gz;
    mpu.getMotion6(&ax, &ay, &az, &gx, &gy, &gz);

    // Convert to meaningful units
    float accelX = ax / 16384.0;
    float accelY = ay / 16384.0;
    float accelZ = az / 16384.0;

    float pitch  = atan2(accelX, sqrt(accelY*accelY + accelZ*accelZ)) * 180.0 / PI;
    float roll   = atan2(accelY, accelZ) * 180.0 / PI;
    float gyroZ  = gz / 131.0; // degrees/second

    // Track cumulative rotation for turn detection in app.js
    unsigned long now = millis();
    float dt = (now - lastGyroTime) / 1000.0;
    lastGyroTime = now;
    cumulativeGyroZ += gyroZ * dt;

    StaticJsonDocument<128> payload;
    payload["heading_deg"]     = 0;      // no magnetometer -- app.js uses phone compass
    payload["pitch_deg"]       = pitch;
    payload["roll_deg"]        = roll;
    payload["gyro_z"]          = gyroZ;
    payload["cumulative_turn"] = cumulativeGyroZ; // total rotation since last reset
    payload["calibrated"]      = imuReady;

    sendJson("imu/orientation", payload);
}

// ============================================================
// Camera capture and send
// ============================================================

// Base64 encoding -- needed to send JPEG bytes as JSON string
static const char b64chars[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

String base64Encode(uint8_t* data, size_t len) {
    String result;
    result.reserve((len / 3 + 1) * 4 + 4);
    for (size_t i = 0; i < len; i += 3) {
        uint8_t b0 = data[i];
        uint8_t b1 = (i+1 < len) ? data[i+1] : 0;
        uint8_t b2 = (i+2 < len) ? data[i+2] : 0;
        result += b64chars[b0 >> 2];
        result += b64chars[((b0 & 3) << 4) | (b1 >> 4)];
        result += (i+1 < len) ? b64chars[((b1 & 0xF) << 2) | (b2 >> 6)] : '=';
        result += (i+2 < len) ? b64chars[b2 & 0x3F] : '=';
    }
    return result;
}

void sendCameraFrame() {
    if (!cameraReady) return;

    camera_fb_t* fb = esp_camera_fb_get();
    if (!fb) {
        Serial.println("[Camera] Failed to capture frame");
        return;
    }

    // Encode JPEG as base64 for JSON transport
    String b64 = base64Encode(fb->buf, fb->len);
    esp_camera_fb_return(fb);

    // Use a separate large document for camera frame
    // since base64 JPEG at 320x240 is ~15-20KB
    DynamicJsonDocument payload(30000);
    payload["frame_id"]   = frameId++;
    payload["width"]      = 320;
    payload["height"]     = 240;
    payload["format"]     = "jpeg";
    payload["simulated"]  = false;
    payload["data"]       = b64;

    sendJson("camera/image", payload);
    Serial.printf("[Camera] Frame %d sent (%d bytes raw)\n", frameId, fb->len);
}

// ============================================================
// Camera initialisation
// ============================================================

bool initCamera() {
    camera_config_t config;
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer   = LEDC_TIMER_0;
    config.pin_d0       = Y2_GPIO_NUM;
    config.pin_d1       = Y3_GPIO_NUM;
    config.pin_d2       = Y4_GPIO_NUM;
    config.pin_d3       = Y5_GPIO_NUM;
    config.pin_d4       = Y6_GPIO_NUM;
    config.pin_d5       = Y7_GPIO_NUM;
    config.pin_d6       = Y8_GPIO_NUM;
    config.pin_d7       = Y9_GPIO_NUM;
    config.pin_xclk     = XCLK_GPIO_NUM;
    config.pin_pclk     = PCLK_GPIO_NUM;
    config.pin_vsync    = VSYNC_GPIO_NUM;
    config.pin_href     = HREF_GPIO_NUM;
    config.pin_sscb_sda = SIOD_GPIO_NUM;
    config.pin_sscb_scl = SIOC_GPIO_NUM;
    config.pin_pwdn     = PWDN_GPIO_NUM;
    config.pin_reset    = RESET_GPIO_NUM;
    config.xclk_freq_hz = 20000000;
    config.pixel_format = PIXFORMAT_JPEG;
    config.frame_size   = FRAMESIZE_QVGA;  // 320x240
    config.jpeg_quality = 15;
    config.fb_count     = 1;

    esp_err_t err = esp_camera_init(&config);
    if (err != ESP_OK) {
        Serial.printf("[Camera] Init failed: 0x%x\n", err);
        return false;
    }
    Serial.println("[Camera] Ready");
    return true;
}

// ============================================================
// Setup
// ============================================================

void setup() {
    Serial.begin(115200);
    delay(1000);
    Serial.println("\n=== NavAssist Full Firmware ===");

    // Motor pins
    pinMode(MOTOR_LEFT_PIN,  OUTPUT);
    pinMode(MOTOR_RIGHT_PIN, OUTPUT);
    digitalWrite(MOTOR_LEFT_PIN,  LOW);
    digitalWrite(MOTOR_RIGHT_PIN, LOW);
    Serial.println("[Motors] GPIO12 (left) and GPIO13 (right) configured");

    // IMU
    Wire.begin(I2C_SDA, I2C_SCL);
    mpu.initialize();
    imuReady = mpu.testConnection();
    Serial.printf("[MPU6050] %s (SDA=GPIO14, SCL=GPIO15)\n",
        imuReady ? "Connected" : "NOT FOUND -- check wiring");
    lastGyroTime = millis();

    // Camera
    cameraReady = initCamera();

    // WiFi
    Serial.printf("[WiFi] Connecting to %s", WIFI_SSID);
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    unsigned long start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
        delay(500);
        Serial.print(".");
    }
    Serial.println();

    if (WiFi.status() == WL_CONNECTED) {
        Serial.printf("[WiFi] Connected! IP: %s\n",
            WiFi.localIP().toString().c_str());
        webSocket.begin(SERVER_IP, SERVER_PORT, "/esp32");
        webSocket.onEvent(onWebSocketEvent);
        webSocket.setReconnectInterval(3000);
    } else {
        Serial.printf("[WiFi] FAILED. Status: %d\n", WiFi.status());
    }

    Serial.println("[Setup] Complete");
    Serial.println("Waiting for server connection...");
}

// ============================================================
// Main loop
// ============================================================

void loop() {
    webSocket.loop();
    unsigned long now = millis();

    // Heartbeat every 2s
    if (now - lastHeartbeat >= 2000) {
        sendHeartbeat();
        lastHeartbeat = now;
    }

    // IMU every 100ms (10Hz)
    if (imuReady && now - lastImu >= 100) {
        sendImuReading();
        lastImu = now;
    }

    // Camera frame every 500ms (2fps) -- only when connected
    if (wsConnected && cameraReady && now - lastFrame >= 500) {
        sendCameraFrame();
        lastFrame = now;
    }
}
